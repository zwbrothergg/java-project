package com.hmdp;

import com.hmdp.service.impl.ShopServiceImpl;
import com.hmdp.utils.RedisIdWorker;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SpringBootTest
public class HmDianPingApplicationTests {

    @Autowired
    private ShopServiceImpl shopService;
    @Resource
    private RedisIdWorker redisIdWorker;

    @Test
    public void testSaveShop(){
        shopService.saveShop2Redis(4L,10L);
    }

    @Test
    void testIdWorker() throws  InterruptedException{
        CountDownLatch latch = new CountDownLatch(300);
        ExecutorService es = Executors.newFixedThreadPool(300);

        Runnable task = () -> {
            for (int i=0;i<100;i++){
                long id = redisIdWorker.nextId("order");
                System.out.println("id =" +id);
            }
            latch.countDown();
        };
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 300; i++) {
            es.submit(task);
        }
        latch.await();
        long end = System.currentTimeMillis();
        System.out.println("time = " + (end - begin));
    }

}
