package com.hmdp.utils;

import cn.hutool.core.lang.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

public class SimpleRedisLock implements ILock {
    private static final String KEY_PREFIX="lock:";
    private static final String ID_PREFIX = UUID.randomUUID().toString(true)+"-";
    private String name;
    private StringRedisTemplate stringRedisTemplate;

    public SimpleRedisLock(String name,StringRedisTemplate stringRedisTemplate){
        this.name = name;
        this.stringRedisTemplate = stringRedisTemplate;
    }


    @Override
    public boolean tryLock(long time) {
        //获取线程id
        String threadId = ID_PREFIX + Thread.currentThread().getId();
        //获取锁
        Boolean success = stringRedisTemplate.opsForValue().setIfAbsent(KEY_PREFIX+ name, threadId,time,TimeUnit.SECONDS);
        return Boolean.TRUE.equals(success);
    }

    /*
    Lua脚本初始化
    创建了一个 DefaultRedisScript 对象用于执行Lua脚本
    脚本文件位于classpath下的 unlock.lua
    脚本返回值类型为 Long
     */
    private static final DefaultRedisScript<Long> UNLOCK_SCRIPT;
    static {
        UNLOCK_SCRIPT = new DefaultRedisScript<>();
        UNLOCK_SCRIPT.setLocation(new ClassPathResource("unlock.lua"));
        UNLOCK_SCRIPT.setResultType(Long.class);
    }
    /*
    工作原理
    这种实现方式的优势在于：
    原子性操作: 通过Lua脚本确保解锁操作的原子性
    安全性: 通过线程ID确保只有加锁的线程才能解锁
    避免删除他人锁: 防止误删其他客户端的锁
     */

    /*
    使用 stringRedisTemplate.execute() 执行Lua脚本
    传递了两个参数：
    KEYS[1]: 锁的键名 (KEY_PREFIX + name)
    ARGV[1]: 当前线程标识符 (ID_PREFIX + Thread.currentThread().getId())
     */
    @Override
    public void unlock() {
        //调用lua脚本
        stringRedisTemplate.execute(
                UNLOCK_SCRIPT,
                Collections.singletonList(KEY_PREFIX + name),
                ID_PREFIX +Thread.currentThread().getId()
        );

    }



//    @Override
//    public void unlock() {
//        //获取线程标识
//        String threadId = ID_PREFIX + Thread.currentThread().getId();
//        //获取锁标识
//        String lockId = stringRedisTemplate.opsForValue().get(KEY_PREFIX+ name);
//
//        if (threadId.equals(lockId)){
//            stringRedisTemplate.delete(KEY_PREFIX+name);
//        }
//    }
}
