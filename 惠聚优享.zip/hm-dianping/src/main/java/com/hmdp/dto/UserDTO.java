package com.hmdp.dto;

import lombok.Data;
import org.apache.ibatis.type.Alias;

@Data
public class UserDTO {
    private Long id;
    private String nickName;
    private String icon;
}
