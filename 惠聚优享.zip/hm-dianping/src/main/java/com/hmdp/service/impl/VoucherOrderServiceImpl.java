package com.hmdp.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.hmdp.dto.Result;
import com.hmdp.entity.SeckillVoucher;
import com.hmdp.entity.Voucher;
import com.hmdp.entity.VoucherOrder;
import com.hmdp.mapper.VoucherOrderMapper;
import com.hmdp.service.ISeckillVoucherService;
import com.hmdp.service.IVoucherOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.utils.RedisIdWorker;
import com.hmdp.utils.SimpleRedisLock;
import com.hmdp.utils.UserHolder;
import com.sun.el.stream.Stream;
import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.connection.stream.*;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.lang.reflect.Proxy;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Slf4j
@Service
public class VoucherOrderServiceImpl extends ServiceImpl<VoucherOrderMapper, VoucherOrder> implements IVoucherOrderService {
    @Autowired
    private ISeckillVoucherService seckillVoucherService;
    @Autowired
    private RedisIdWorker redisIdWorker;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;


    private static final DefaultRedisScript<Long> SECKILL_SCRIPT;
    static {
        SECKILL_SCRIPT = new DefaultRedisScript<>();
        SECKILL_SCRIPT.setLocation(new ClassPathResource("seckill.lua"));
        SECKILL_SCRIPT.setResultType(Long.class);
    }

    private BlockingQueue<VoucherOrder> orderTasks = new ArrayBlockingQueue<>(1024*1024);

    //异步处理线程池
    private  static  final ExecutorService SECKILL_ORDER_EXECUTOR = Executors.newSingleThreadExecutor();

    //在类初始化之后执行，因为当这个类初始化好了之后，随时都是有可能要执行
    @PostConstruct
    private void init(){
        SECKILL_ORDER_EXECUTOR.submit(new VoucherOrderHandler());
    }

//    //用于线程池处理任务
//    //当初始化完毕后，就回去队列中去拿信息
//    //使用阻塞队列
//    private class VoucherOrderHandler implements Runnable{
//
//        @Override
//        public void run() {
//            while (true) {
//                try {
//                    //1.获取队列中的订单信息
//                    VoucherOrder voucherOrder = orderTasks.take();
//                    //2.创建订单
//                    proxy.save(voucherOrder);
//                } catch (Exception e) {
//                    log.error("处理订单异常",e);
//                }
//            }
//        }

    //用于线程池处理任务
    //当初始化完毕后，就回去队列中去拿信息
    //使用消息队列
    private class VoucherOrderHandler implements Runnable{
        @Override
        public void run() {
            //创建一个无限循环，持续监听和处理消息队列中的订单任务
            while (true) {
                try {
                    //1.获取消息队列中的订单信息
                    List<MapRecord<String,Object,Object>> list = stringRedisTemplate.opsForStream().read(
                            Consumer.from("g1","c1"),
                            StreamReadOptions.empty().count(1).block(Duration.ofSeconds(2)),
                            //count(1): 每次最多读取1条消息
                            //block(Duration.ofSeconds(2)): 阻塞等待2秒，如果没有消息则返回
                            StreamOffset.create("stream.orders",ReadOffset.lastConsumed())//从 "stream.orders" 流中读取,只读取最新的消息
                    );
                    //2.判断订单是否为空
                    if (list == null || list.isEmpty()){
                        continue;
                    }
                    //解析数据
                    MapRecord<String,Object,Object> record = list.get(0);
                    Map<Object,Object> value = record.getValue();
                    VoucherOrder voucherOrder = BeanUtil.fillBeanWithMap(value,new VoucherOrder(),true);
                    //3.创建订单
                    proxy.save(voucherOrder);
                    //4.确认消息
                    stringRedisTemplate.opsForStream().acknowledge("s1","g1",record.getId());

                } catch (Exception e) {
                    log.error("处理订单异常",e);
                    handlePendingList();
                }
            }
        }

        private void handlePendingList() {
            while (true){
                try {
                    // 1.获取pending-list中的订单信息 XREADGROUP GROUP g1 c1 COUNT 1 BLOCK 2000 STREAMS s1 0
                    List<MapRecord<String, Object, Object>> list = stringRedisTemplate.opsForStream().read(
                            Consumer.from("g1", "c1"),
                            StreamReadOptions.empty().count(1),
                            StreamOffset.create("stream.orders", ReadOffset.from("0"))
                    );
                    // 2.判断订单信息是否为空
                    if (list == null || list.isEmpty()) {
                        // 如果为null，说明没有异常消息，结束循环
                        break;
                    }
                    // 解析数据
                    MapRecord<String, Object, Object> record = list.get(0);
                    Map<Object, Object> value = record.getValue();
                    VoucherOrder voucherOrder = BeanUtil.fillBeanWithMap(value, new VoucherOrder(), true);
                    // 3.创建订单
                    proxy.save(voucherOrder);
                    // 4.确认消息 XACK
                    stringRedisTemplate.opsForStream().acknowledge("s1", "g1", record.getId());
                }catch (Exception e){
                    log.error("处理pendding订单异常",e);
                    try {
                        Thread.sleep(20);
                    }catch (Exception e1){
                        e1.printStackTrace();;
                    }
                }
            }
        }
    }

    private IVoucherOrderService proxy;

    @Override
    public Result seckillVoucher(Long voucherId) {
        //获取用户
        Long userId = UserHolder.getUser().getId();
        long orderId = redisIdWorker.nextId("order");
        //1.执行lua脚本
        Long result = stringRedisTemplate.execute(
                SECKILL_SCRIPT,
                Collections.emptyList(),
                voucherId.toString(),userId.toString(),String.valueOf(orderId)//将基本数据类型 long 转换为 String 类型
        );
        /*基本数据类型与字符串类型转换
        String.valueOf(orderId) - 推荐方式，适用于基本数据类型
        orderId.toString() - 不能用于基本数据类型，只能用于包装类型对象
        "" + orderId - 字符串拼接方式，但性能略低
         */
        int r = result.intValue();//用于将 Integer 对象转换为对应的 int 基本数据类型
        //2.判断结果是否为0
        if (r!=0){
            return Result.fail(r==1?"库存不足":"不能重复下单");
        }

//        //TODO保存阻塞队列
//        VoucherOrder voucherOrder = new VoucherOrder();
//        voucherOrder.setUserId(userId);
//        voucherOrder.setVoucherId(orderId);
//        voucherOrder.setVoucherId(voucherId);
//        orderTasks.add(voucherOrder);
//
        //获取代理对象
        proxy = (IVoucherOrderService) AopContext.currentProxy();

        //3.返回订单id
        return Result.ok(orderId);
    }


//    @Override
//    public Result seckillVoucher(Long voucherId) {
//        //1.查询优惠卷信息
//        SeckillVoucher seckillVoucher = seckillVoucherService.getById(voucherId);
//        //2.判断秒杀时间是否已经开始
//        if (LocalDateTime.now().isBefore(seckillVoucher.getBeginTime())) {
//            //未开始
//            return Result.fail("秒杀未开始");
//        }
//        if (LocalDateTime.now().isAfter(seckillVoucher.getEndTime())) {
//            return Result.fail("秒杀已结束");
//        }
//        //已经开始
//        //判断库存是否充足
//        if (seckillVoucher.getStock() < 1) {
//            //不足
//            return Result.fail("秒杀卷已经被抢光");
//        }
//        //库存充足
//        Long userId = UserHolder.getUser().getId();
//
//        //创建锁对象
//        SimpleRedisLock lock = new SimpleRedisLock("order:" + userId, stringRedisTemplate);
//        //获取锁
//        boolean islock = lock.tryLock(1200);
//        if (!islock) {
//            return Result.fail("一人只能下一单");
//        }
//        try {
//            //获取代理对象
//            IVoucherOrderService proxy = (IVoucherOrderService) AopContext.currentProxy();
//            return proxy.createvoucherorder(voucherId);
//        } finally {
//            lock.unlock();
//        }
//    }


//        在单体项目中使用锁
//        synchronized(userId.toString().intern()){
//            //获取代理对象
//            IVoucherOrderService proxy = (IVoucherOrderService) AopContext.currentProxy();
//            return proxy.createvoucherorder(voucherId);
//        }




    @Transactional
    public Result createvoucherorder(Long voucherId){
        //5.一人一单
        Long userId = UserHolder.getUser().getId();
        int count = query().eq("user_id",userId).eq("voucher_id",voucherId).count();
        if (count > 0){
            return Result.fail("一人只能下一单");
        }
        //扣除库存
        boolean success = seckillVoucherService.update().setSql("stock= stock -1").eq("voucher_id",voucherId).gt("stock",0).update();
        if (!success){
            return  Result.fail("秒杀卷已经被抢光");
        }
        //6.创建订单
        VoucherOrder voucherOrder = new VoucherOrder();
        // 6.1.订单id
        long orderId = redisIdWorker.nextId("order");
        voucherOrder.setId(orderId);
        // 6.2.用户id
        //Long userId = UserHolder.getUser().getId();
        voucherOrder.setUserId(userId);
        // 6.3.代金券id
        voucherOrder.setVoucherId(voucherId);
        save(voucherOrder);
        return Result.ok(orderId);

    }
}
