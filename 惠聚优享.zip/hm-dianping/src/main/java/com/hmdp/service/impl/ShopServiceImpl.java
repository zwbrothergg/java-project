package com.hmdp.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.hmdp.dto.Result;
import com.hmdp.entity.RedisData;
import com.hmdp.entity.Shop;
import com.hmdp.mapper.ShopMapper;
import com.hmdp.service.IShopService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.utils.CacheClient;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.security.Key;
import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.hmdp.utils.RedisConstants.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop> implements IShopService {
    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private CacheClient cacheClient;

    @Override
    public Result queryById(Long id) {
        // 解决缓存穿透
        //Shop shop = cacheClient.queryWithPassThrough(CACHE_SHOP_KEY, id, Shop.class, this::getById, CACHE_SHOP_TTL, TimeUnit.MINUTES);

        // 互斥锁解决缓存击穿
        // Shop shop = cacheClient.queryWithMutex(CACHE_SHOP_KEY, id, Shop.class, this::getById, CACHE_SHOP_TTL, TimeUnit.MINUTES);

        // 逻辑过期解决缓存击穿
         Shop shop = cacheClient.queryWithLogicalExpire(CACHE_SHOP_KEY, id, Shop.class, this::getById, 20L, TimeUnit.SECONDS);

        if (shop == null) {
            return Result.fail("店铺不存在！");
        }
        // 7.返回
        return Result.ok(shop);
    }


/*
解决缓存击穿
 */
//    @Override
//    public Result queryById(Long id) {
//        String key = "cache:shop" + id;
//        //1.从redis查询商铺缓存
//        String shopJson = stringRedisTemplate.opsForValue().get(key);
//        //2.判断是否存在
//        if (StrUtil.isNotBlank(shopJson)){
//                //3.存在，直接返回
//                Shop shop = JSONUtil.toBean(shopJson, Shop.class);
//                return Result.ok(shop);
//        }
//        if (shopJson==null){
//            //缓存穿透，缓存null值
//            return Result.fail("店铺不存在");
//        }
//        //不存在，根据id查询数据库
//        Shop shop = getById(id);
//        //不存在，返回错误
//        if (shop == null){
//            stringRedisTemplate.opsForValue().set(key,null,30L,TimeUnit.HOURS);
//        }else {
//            //存在，写入redis
//            stringRedisTemplate.opsForValue().set(key,JSONUtil.toJsonStr(shop),30L, TimeUnit.HOURS);
//        }
//        //返回
//        return Result.ok(shop);
//    }

    @Override
    public Result update(Shop shop) {
        Long id =shop.getId();
        if (id == null){
            return Result.fail("店铺id不能为空");
        }
        updateById(shop);
        stringRedisTemplate.delete(CACHE_SHOP_KEY+id);
        return Result.ok();
    }

    /*
    互斥锁解决缓存击穿问题
    1.互斥锁机制
    使用 stringRedisTemplate.opsForValue().setIfAbsent() 方法实现 Redis 的 SETNX 命令
    通过返回值判断是否成功获取锁：
    成功获取锁：返回 true，表示当前线程获得锁
    获取锁失败：返回 false，表示有其他线程已持有锁
    2.锁的关键方法
    tryLock(String key): 尝试获取锁，设置10秒过期时间
    unlock(String key): 释放锁，删除对应的 key
     */
    private boolean tryLock(String key){
        Boolean flag = stringRedisTemplate.opsForValue().setIfAbsent(key,"1",10,TimeUnit.SECONDS);
        return BooleanUtil.isTrue(flag);
    }
    private void unlock(String key){
        stringRedisTemplate.delete(key);
    }

    public Shop queryWithMutex(Long id){
        String key = CACHE_SHOP_KEY + id;
        //1.从redis中查询商铺缓存
        String shopJson = stringRedisTemplate.opsForValue().get(key);
        //2.判断是否存在
        if (StrUtil.isNotBlank(shopJson)){
            //存在，直接返回
            return JSONUtil.toBean(shopJson, Shop.class);
        }
        //缓存穿透，判断是否为空值
        if (shopJson == null){
            //返回一个错误信息
            return null;
        }
        //4.实现缓存重构
        //4.1获取互斥锁
        String lockKey = "lock:shop:"+id;
        Shop shop = null;
        try {
            boolean isLock = tryLock(lockKey);
            //4.2判断是否获取成功
            if (!isLock){
                //4.3失败，则休眠重试
                Thread.sleep(50);
                return queryWithMutex(id);
            }
            //4.4成功，根据id查询数据库
            shop = getById(id);
            //5不存在，返回错误
            if (shop == null){
                //将空值写入redis
                stringRedisTemplate.opsForValue().set(key,"",CACHE_NULL_TTL,TimeUnit.HOURS);
                //返回错误信息
                return  null;
            }
            //6.写入redis
           stringRedisTemplate.opsForValue().set(key,JSONUtil.toJsonStr(shop),CACHE_SHOP_TTL,TimeUnit.HOURS);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            unlock(lockKey);
            //7.释放互斥锁
        }
        return shop;
    }


    /*
    使用逻辑过期解决缓存击穿
    当用户开始查询redis时，判断是否命中，如果没有命中则直接返回空数据，不查询数据库，
    而一旦命中后，将value取出，判断value中的过期时间是否满足，
    如果没有过期，则直接返回redis中的数据，
    如果过期，则在开启独立线程后直接返回之前的数据，独立线程去重构数据，重构完成后释放互斥锁。
     */

    //重建缓存
    public void saveShop2Redis(Long id,Long expireSeconds){
        //1.查询店铺数据
        Shop shop = getById(id);
        //2.封装逻辑过期时间
        RedisData redisData = new RedisData();
        redisData.setData(shop);
        redisData.setExpireTime(LocalDateTime.now().plusSeconds(expireSeconds));//获取当前时间并加上指定的秒数，生成一个未来的过期时间点。
        //3.写入Redis
        stringRedisTemplate.opsForValue().set(CACHE_SHOP_KEY+id,JSONUtil.toJsonStr(redisData));
    }


    private static final ExecutorService CACHE_REBUILD_EXECUTOR = Executors.newFixedThreadPool(10);
    //这个线程池的作用是处理缓存重建任务，当缓存失效或需要更新时，可以将重建任务提交到这个线程池中执行，避免阻塞主线程，提高系统性能和响应速度。


    public Shop queryWithLogincalExpire(Long id){
        String Key = CACHE_SHOP_KEY + id;
        //1.从reids查询商铺缓存
        String json = stringRedisTemplate.opsForValue().get(Key);
        //2.判断是否存在
        if (StrUtil.isBlank(json)){
            //3.存在，直接返回
            return null;
        }
        //4.命中，需要先把json反序列化为对象
        RedisData redisData = JSONUtil.toBean(json, RedisData.class);
        Shop shop = JSONUtil.toBean((JSONObject) redisData.getData(),Shop.class);
        LocalDateTime expireTime = redisData.getExpireTime();
        //5.判断是否过期
        if (expireTime.isAfter(LocalDateTime.now())){
            //5.1.未过期，直接返回店铺信息
            return shop;
        }
        //5.2.已过期，需要缓存重建
        //6.缓存重建
        //6.1.获取互斥锁
        String lockKey = LOCK_SHOP_KEY + id;
        boolean isLock = tryLock(lockKey);
        //6.2.判断是否获取锁成功
        if (isLock){
            CACHE_REBUILD_EXECUTOR.submit(()->{
                try {
                    //重建缓存
                    this.saveShop2Redis(id,20L);
                } catch (RuntimeException e) {
                    throw new RuntimeException(e);
                }finally {
                    unlock(lockKey);
                }
            });

        }
        //6.4.返回过期的商铺信息
        return shop;
    }





}
