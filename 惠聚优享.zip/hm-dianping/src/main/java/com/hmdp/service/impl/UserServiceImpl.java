package com.hmdp.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.dto.LoginFormDTO;
import com.hmdp.dto.Result;
import com.hmdp.dto.UserDTO;
import com.hmdp.entity.User;
import com.hmdp.mapper.UserMapper;
import com.hmdp.service.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.hmdp.utils.RedisConstants.*;
import static com.hmdp.utils.RegexUtils.isPhoneInvalid;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Result sentCode(String phone, HttpSession session) {
        //校验手机号码
        if(isPhoneInvalid(phone)){
            //不符合
            return Result.fail("手机号码格式不符合");
        }
        //符合，生成校验码
        String code = RandomUtil.randomNumbers(6);
        //保存验证码到redis
//        session.setAttribute("code",code);
        stringRedisTemplate.opsForValue().set(LOGIN_CODE_KEY+phone,code,LOGIN_CODE_TTL,TimeUnit.HOURS);
        //发送验证码
        log.debug("发送验证码成功，验证码：{}",code);
        return Result.ok();
    }

    @Override
    public Result login(LoginFormDTO loginForm, HttpSession session) {
        //校验手机号码
        String phone = loginForm.getPhone();
        if(isPhoneInvalid(phone)){
            //格式不符合
            return Result.fail("手机号码格式不符合");
        }

        //从redis中获取验证码，校验验证码
//        Object cacheCode = session.getAttribute("code");
        String cacheCode = stringRedisTemplate.opsForValue().get(LOGIN_CODE_KEY+phone);
        String code = loginForm.getCode();
        if (cacheCode == null || !cacheCode.equals(code)){
            return Result.fail("验证码错误");
        }

        //一致，根据手机号码查询用户
        User user = query().eq("phone",phone).one();
        //判断用户是否存在
        if (user==null){
            //用户不存在，创建新用户
            user = createwithphone(phone);
        }
//        //保存用户信息到session
//        session.setAttribute("user", BeanUtil.copyProperties(user, UserDTO.class));
//        System.out.println("user:" + session.getAttribute("user"));

        // 7.保存用户信息到redis
        //7.1.随机生成token，作为登陆令牌
        String token = UUID.randomUUID().toString(true);

        //7.2.将user对象转换为HashMap存储
        //Map<String,Object> userMap = BeanUtil.beanToMap(user);
        // 将 User 对象转换为 Map 并存储到 Redis 时。问题在于 User 实体类中某些字段是 Long 类型（如 id），但在使用 BeanUtil.beanToMap() 转换后，这些 Long 值被直接存储到 Redis Hash 中，当从 Redis 读取时尝试将它们转换为 String 就会抛出类型转换异常。
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("id", user.getId().toString());
        userMap.put("phone", user.getPhone());
        userMap.put("nickName", user.getNickName());

        //7.3.存储
        String tokenkey = LOGIN_USER_KEY + token;
        stringRedisTemplate.opsForHash().putAll(tokenkey,userMap);

        //7.4设置token有效期
        stringRedisTemplate.expire(tokenkey,LOGIN_USER_TTL,TimeUnit.MINUTES);
        //8.返回token
        return Result.ok(token);
    }

    private User createwithphone(String phone) {
        User user = new User();
        user.setPhone(phone);
        user.setNickName("user_"+RandomUtil.randomString(10));
        save(user);
        return  user;
    }
}
