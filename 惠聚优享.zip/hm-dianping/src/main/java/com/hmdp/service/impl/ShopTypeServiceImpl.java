package com.hmdp.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.hmdp.dto.Result;
import com.hmdp.entity.ShopType;
import com.hmdp.mapper.ShopTypeMapper;
import com.hmdp.service.IShopTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class ShopTypeServiceImpl extends ServiceImpl<ShopTypeMapper, ShopType> implements IShopTypeService {

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public List<ShopType> queryshoptype() {
        String key ="cache:shoptype:";
        //从redis获取商铺类型缓存
        String shoptype = stringRedisTemplate.opsForValue().get(key);
        //判断缓存是否命中
        if (StrUtil.isNotBlank(shoptype)){
            //命中，返回商铺类型信息
            return  JSONUtil.toList(shoptype,ShopType.class);
        }
        //未命中，查询数据库
        List<ShopType> shopTypeList = query().list();
        //判断商铺类型是否存在，
        if (shopTypeList == null || shopTypeList.isEmpty()){
            return Collections.emptyList();
        }
        //存在，将商铺类型写进redis
        stringRedisTemplate.opsForValue().set(key,JSONUtil.toJsonStr(shopTypeList));
        //不存在，返回404
        return shopTypeList;
    }
}
